#!/usr/bin/env bash
# Combine selected personas into active profile
set -euo pipefail

selected_personas=("$@")
output="profiles/personas/combined/active.json"

mkdir -p profiles/personas/combined

echo '{"personas": [' > "$output"
first=true
for persona in "${selected_personas[@]}"; do
  if [[ -f "profiles/personas/individual/${persona}.json" ]]; then
    [[ "$first" == "false" ]] && echo "," >> "$output"
    cat "profiles/personas/individual/${persona}.json" >> "$output"
    first=false
  fi
done
echo ']}' >> "$output"

echo "Combined personas: ${selected_personas[*]}"
